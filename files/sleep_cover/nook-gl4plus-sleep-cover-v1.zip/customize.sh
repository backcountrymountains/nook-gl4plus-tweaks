set_perm "$MODPATH/service.sh"       root root 0755
set_perm "$MODPATH/cover_watcher.sh" root root 0755
set_perm "$MODPATH/cover_handler.sh" root root 0755
