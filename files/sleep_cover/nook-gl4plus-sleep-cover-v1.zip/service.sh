#!/system/bin/sh
# Run by Magisk on every boot.
# All event-driven logic lives in cover_watcher.sh (logcat-based, no poll timers).

MODULE_DIR=/data/adb/modules/sleep_cover

# Suppress the SystemUI high-temperature warning dialog.
# The Settings provider may not be ready at late-start time on this device;
# poll in the background until the write succeeds.
(
    TRIES=0
    until settings put global show_temperature_warning 0 2>/dev/null || [ $TRIES -ge 30 ]; do
        sleep 2
        TRIES=$((TRIES + 1))
    done
) &

# Start the event-driven watcher for sleep cover propagation.
"$MODULE_DIR/cover_watcher.sh" &
