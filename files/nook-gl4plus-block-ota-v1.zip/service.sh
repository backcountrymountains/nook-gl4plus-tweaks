#!/system/bin/sh
# Run by Magisk as root after every boot.
# All operations are idempotent — safe to re-run.

# Disable OTA update components.
pm disable com.nook.partner/.otamanager.OtaIntentService  >/dev/null 2>&1
pm disable com.nook.partner/.otamanager.SideloadInstaller >/dev/null 2>&1
pm disable com.nook.partner/.oobe.OobeOtaActivity         >/dev/null 2>&1

# Redirect the OTA server URL to localhost.
# com.nook.partner reads this file on startup and uses it instead of the
# real B&N endpoint — a belt-and-suspenders fallback in case components
# are ever re-enabled.
echo 'http://127.0.0.1/' > /sdcard/ota_server.conf
