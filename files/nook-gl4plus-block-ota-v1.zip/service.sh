#!/system/bin/sh
# Run by Magisk as root after every boot.
# All operations are idempotent — safe to re-run.

# Disable OTA update components.
# pm disable talks directly to PackageManager — available at late-start time.
pm disable com.nook.partner/.otamanager.OtaIntentService  >/dev/null 2>&1
pm disable com.nook.partner/.otamanager.SideloadInstaller >/dev/null 2>&1
pm disable com.nook.partner/.oobe.OobeOtaActivity         >/dev/null 2>&1

# Redirect the OTA server URL to localhost.
# /sdcard is a FUSE mount that isn't available at late-start service time;
# poll in the background until it is writable, then write the file.
(
    TRIES=0
    until [ -w /sdcard ] || [ $TRIES -ge 30 ]; do
        sleep 2
        TRIES=$((TRIES + 1))
    done
    echo 'http://127.0.0.1/' > /sdcard/ota_server.conf
) &
