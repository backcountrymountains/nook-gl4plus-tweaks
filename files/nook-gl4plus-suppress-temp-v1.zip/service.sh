#!/system/bin/sh
# Run by Magisk as root after every boot.
# All operations are idempotent — safe to re-run.

# Disable the nookPartner temperature warning layer.
# pm/am talk directly to system services — available at late-start time.
pm disable com.nook.partner/.statusbar.StatusBarService >/dev/null 2>&1
am force-stop com.nook.partner >/dev/null 2>&1

# Suppress the SystemUI temperature warning layer.
# The Settings provider may not be ready at late-start time on this device;
# poll in the background until the write succeeds.
(
    TRIES=0
    until settings put global show_temperature_warning 0 2>/dev/null || [ $TRIES -ge 30 ]; do
        sleep 2
        TRIES=$((TRIES + 1))
    done
) &
