#!/system/bin/sh
# Run by Magisk as root after every boot.
# All operations are idempotent — safe to re-run.

# Disable the nookPartner temperature warning layer.
pm disable com.nook.partner/.statusbar.StatusBarService >/dev/null 2>&1
am force-stop com.nook.partner >/dev/null 2>&1

# Suppress the SystemUI temperature warning layer.
settings put global show_temperature_warning 0
