#!/system/bin/sh
# Run by Magisk as root after every boot.
# All operations are idempotent — safe to re-run.

# Disable the nookPartner temperature warning layer (BatteryIcon inside
# StatusBarService). GlowLightService (warmth control) is a separate
# service in the same package and is NOT affected by this change.
pm disable com.nook.partner/.statusbar.StatusBarService >/dev/null 2>&1

# Kill any already-running StatusBarService instance from this boot.
am force-stop com.nook.partner >/dev/null 2>&1

# Suppress the SystemUI temperature warning layer.
settings put global show_temperature_warning 0
